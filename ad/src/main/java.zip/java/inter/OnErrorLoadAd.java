package inter;

/**
 * Created by d on 1/24/2018.
 */

public interface OnErrorLoadAd {
    public void onError();
}
